# Landing Page Project

## Table of Contents

* html for page structure (from udacity course)
* css for page styling (from udacity course and some google search)
* java script and dom for interaction and dynamic (from udacity course and some google search)
* media query to responsive any device
* responsibility for all devices and usabilty
* fixed header contain nav bar for lists
* smooth scrolling
* show what section is being viewed while scrolling
* four sections each seciton has heaing and paragraph
* addEventListener was added and scrollIntoView
* at first section addEventListener image disappear on click and appear on double click (made by dom)
* footer at end of the page


## SOURCES

* https://www.w3schools.com/
* https://developer.mozilla.org/en-US/
* some google search and other resources

I hope you like this project

Thank You! OMAR METWALLY